// Dados simulados de login
const usuarios = {
    admin: { senha: "admin", role: "admin" },
    tecnico: { senha: "123", role: "tecnico" }
};

// Estado global
let usuarioLogado = null;
let chamados = [];
let clientes = [];
let estoque = [];
let tecnicos = ["tecnico"];

// Render inicial
document.getElementById("app").innerHTML = `
    <header><h1>Helpdesk + Estoque</h1></header>
    <div class="container" id="login-container">
        <h2>Login</h2>
        <input type="text" id="login-usuario" placeholder="Usuário">
        <input type="password" id="login-senha" placeholder="Senha">
        <button onclick="login()">Entrar</button>
    </div>
    <div id="main-container" class="hidden">
        <nav id="menu"></nav>
        <div class="container" id="content"></div>
    </div>
`;

function login() {
    const user = document.getElementById("login-usuario").value;
    const pass = document.getElementById("login-senha").value;

    if (usuarios[user] && usuarios[user].senha === pass) {
        usuarioLogado = { nome: user, role: usuarios[user].role };
        document.getElementById("login-container").classList.add("hidden");
        document.getElementById("main-container").classList.remove("hidden");
        renderMenu();
    } else {
        alert("Credenciais inválidas!");
    }
}

function logout() {
    usuarioLogado = null;
    document.getElementById("main-container").classList.add("hidden");
    document.getElementById("login-container").classList.remove("hidden");
}

// Renderizar menu dinâmico
function renderMenu() {
    let menuHTML = `
        <button onclick="renderChamados()">Chamados</button>
        <button onclick="renderClientes()">Clientes</button>
        <button onclick="renderEstoque()">Estoque</button>
    `;

    if (usuarioLogado.role === "admin") {
        menuHTML += `<button onclick="renderUsuarios()">Usuários</button>`;
    }

    menuHTML += `<button onclick="logout()">Sair</button>`;
    document.getElementById("menu").innerHTML = menuHTML;
    renderChamados();
}

// -------- CHAMADOS --------
function renderChamados() {
    document.getElementById("content").innerHTML = `
        <h2>Chamados</h2>
        <form onsubmit="adicionarChamado(event)">
            <input type="text" id="chamado-titulo" placeholder="Título" required>
            <textarea id="chamado-desc" placeholder="Descrição" required></textarea>
            <select id="chamado-status">
                <option value="Aberto">Aberto</option>
                <option value="Fechado">Fechado</option>
                <option value="Aguardando Material">Aguardando Material</option>
            </select>
            <input type="date" id="chamado-sla" required>
            <input type="file" id="chamado-anexo" accept=".jpg,.png,.pdf,.txt">
            <button type="submit">Adicionar Chamado</button>
        </form>
        <table>
            <tr><th>Título</th><th>Descrição</th><th>Status</th><th>SLA</th><th>Anexo</th></tr>
            ${chamados.map(c => `
                <tr>
                    <td>${c.titulo}</td>
                    <td>${c.desc}</td>
                    <td class="${c.status === "Aberto" ? "status-aberto" : c.status === "Fechado" ? "status-fechado" : "status-aguardando"}">${c.status}</td>
                    <td>${c.sla}</td>
                    <td>${c.anexo ? `<a href="${c.anexo}" target="_blank">Ver</a>` : "-"}</td>
                </tr>
            `).join("")}
        </table>
    `;
}

function adicionarChamado(e) {
    e.preventDefault();
    const titulo = document.getElementById("chamado-titulo").value;
    const desc = document.getElementById("chamado-desc").value;
    const status = document.getElementById("chamado-status").value;
    const sla = document.getElementById("chamado-sla").value;
    const fileInput = document.getElementById("chamado-anexo");
    let anexo = null;

    if (fileInput.files.length > 0) {
        const reader = new FileReader();
        reader.onload = function(evt) {
            chamados.push({ titulo, desc, status, sla, anexo: evt.target.result });
            renderChamados();
        };
        reader.readAsDataURL(fileInput.files[0]);
    } else {
        chamados.push({ titulo, desc, status, sla, anexo });
        renderChamados();
    }
}

// -------- CLIENTES --------
function renderClientes() {
    document.getElementById("content").innerHTML = `
        <h2>Clientes</h2>
        <form onsubmit="adicionarCliente(event)">
            <input type="text" id="cliente-nome" placeholder="Nome do Cliente" required>
            <input type="text" id="cliente-email" placeholder="Email" required>
            <input type="text" id="cliente-telefone" placeholder="Telefone" required>
            <button type="submit">Adicionar Cliente</button>
        </form>
        <table>
            <tr><th>Nome</th><th>Email</th><th>Telefone</th></tr>
            ${clientes.map(c => `
                <tr><td>${c.nome}</td><td>${c.email}</td><td>${c.telefone}</td></tr>
            `).join("")}
        </table>
    `;
}

function adicionarCliente(e) {
    e.preventDefault();
    const nome = document.getElementById("cliente-nome").value;
    const email = document.getElementById("cliente-email").value;
    const telefone = document.getElementById("cliente-telefone").value;
    clientes.push({ nome, email, telefone });
    renderClientes();
}

// -------- ESTOQUE --------
function renderEstoque() {
    document.getElementById("content").innerHTML = `
        <h2>Estoque</h2>
        <form onsubmit="adicionarEstoque(event)">
            <input type="text" id="estoque-nome" placeholder="Nome do Item" required>
            <input type="number" id="estoque-qtd" placeholder="Quantidade" required>
            <button type="submit">Adicionar Item</button>
        </form>
        <table>
            <tr><th>Item</th><th>Quantidade</th></tr>
            ${estoque.map(e => `
                <tr><td>${e.nome}</td><td>${e.qtd}</td></tr>
            `).join("")}
        </table>
    `;
}

function adicionarEstoque(e) {
    e.preventDefault();
    const nome = document.getElementById("estoque-nome").value;
    const qtd = document.getElementById("estoque-qtd").value;
    estoque.push({ nome, qtd });
    renderEstoque();
}

// -------- USUÁRIOS (somente admin) --------
function renderUsuarios() {
    document.getElementById("content").innerHTML = `
        <h2>Usuários</h2>
        <form onsubmit="adicionarUsuario(event)">
            <input type="text" id="user-nome" placeholder="Usuário" required>
            <input type="password" id="user-senha" placeholder="Senha" required>
            <select id="user-role">
                <option value="tecnico">Técnico</option>
                <option value="admin">Administrador</option>
            </select>
            <button type="submit">Adicionar Usuário</button>
        </form>
        <table>
            <tr><th>Usuário</th><th>Função</th></tr>
            ${Object.keys(usuarios).map(u => `
                <tr><td>${u}</td><td>${usuarios[u].role}</td></tr>
            `).join("")}
        </table>
    `;
}

function adicionarUsuario(e) {
    e.preventDefault();
    const nome = document.getElementById("user-nome").value;
    const senha = document.getElementById("user-senha").value;
    const role = document.getElementById("user-role").value;
    if (!usuarios[nome]) {
        usuarios[nome] = { senha, role };
        renderUsuarios();
    } else {
        alert("Usuário já existe!");
    }
}